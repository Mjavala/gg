
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'mjavala',
  applicationName: 'twitch-tipper-abs',
  appUid: '15ntMxvnH25PJBcwBz',
  orgUid: '99f4ea04-0875-43a9-aff1-e6126acd1ae0',
  deploymentUid: 'f1e26972-47d7-406a-89ba-c873c1c1612e',
  serviceName: 'twitch-tipper-abs',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'twitch-tipper-abs-dev-app', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}